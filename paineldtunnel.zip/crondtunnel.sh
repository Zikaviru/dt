#!/bin/bash
cd /etc/paineldtunnel || exit && npm run start && cd || exit
